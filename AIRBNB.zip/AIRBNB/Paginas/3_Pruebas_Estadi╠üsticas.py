# Paginas/3_Pruebas_Estadísticas.py
import streamlit as st
import pandas as pd
import numpy as np
from scipy import stats

DATA = st.session_state.data
NUMERIC_VARS = st.session_state.numeric_vars


# CSS PROFESIONAL

st.markdown("""
<style>
    .table-container {
        background: white;
        padding: 1.5rem;
        border-radius: 16px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.08);
        border: 1px solid #E5E7EB;
        margin: 1.5rem 0;
    }
    .table-title {
        font-size: 1.3rem;
        font-weight: 600;
        color: #1F2937;
        margin-bottom: 0.5rem;
    }
    .findings-box {
        background: #FFF4F4;
        padding: 1.2rem;
        border-radius: 12px;
        border-left: 5px solid #FF5A5F;
        margin: 1.5rem 0;
        font-size: 0.95rem;
    }
    .sidebar .sidebar-content {
        background: #F9FAFB;
        border-right: 1px solid #E5E7EB;
        padding: 0 !important;
    }
    .sidebar-header {
        background: #FF5A5F;
        color: white;
        padding: 1rem;
        border-radius: 12px 12px 0 0;
        text-align: center;
        font-weight: 600;
        font-size: 1.2rem;
        margin: 0 0.8rem 0.8rem 0.8rem !important;
    }
    .sidebar-section {
        background: white;
        padding: 0.8rem 1rem;
        border-radius: 12px;
        margin: 0 0.8rem 0.8rem 0.8rem !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        border: 1px solid #E5E7EB;
    }
    .sidebar .stSelectbox > div > div,
    .sidebar .stMultiselect > div {
        margin: 0 !important;
        padding: 0.4rem 0 !important;
    }
</style>
""", unsafe_allow_html=True)


# SIDEBAR PROFESIONAL Y COMPACTO

with st.sidebar:
    st.markdown('<div class="sidebar-header">Pruebas Estadísticas</div>', unsafe_allow_html=True)

    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Variable Numérica**", unsafe_allow_html=True)
    test_var = st.selectbox("", options=NUMERIC_VARS, index=0, label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Ciudades para comparar**", unsafe_allow_html=True)
    cities = st.multiselect("", options=list(DATA.keys()), default=list(DATA.keys())[:2], label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)


# TÍTULO

st.markdown("## Pruebas t-Student entre Ciudades")

if len(cities) < 2:
    st.warning("Selecciona al menos 2 ciudades para comparar.")
    st.stop()


# DATOS Y PRUEBAS

arrays = {}
for city in cities:
    df = DATA[city]
    if test_var in df.columns:
        values = df[test_var].dropna()
        arrays[city] = values.values if len(values) > 0 else np.array([])
    else:
        arrays[city] = np.array([])

rows = []
city_list = [c for c in cities if len(arrays[c]) > 1]

for i in range(len(city_list)):
    for j in range(i + 1, len(city_list)):
        a, b = city_list[i], city_list[j]
        arr_a, arr_b = arrays[a], arrays[b]
        
        mean_a = np.mean(arr_a)
        mean_b = np.mean(arr_b)
        delta = mean_a - mean_b
        
        try:
            tstat, pvalue = stats.ttest_ind(arr_a, arr_b, equal_var=False, nan_policy='omit')
        except:
            tstat, pvalue = np.nan, np.nan
        
        rows.append({
            "Ciudad A": a,
            "Ciudad B": b,
            "Media A": round(mean_a, 2),
            "Media B": round(mean_b, 2),
            "Diferencia": round(delta, 2),
            "t-stat": round(tstat, 3) if not np.isnan(tstat) else "N/A",
            "p-value": round(pvalue, 4) if not np.isnan(pvalue) else "N/A",
            "n_A": len(arr_a),
            "n_B": len(arr_b)
        })


# TABLA CON MARCO

if rows:
    df_tests = pd.DataFrame(rows)

    # Resaltar p-value < 0.05
    def highlight_pval(val):
        try:
            p = float(val)
            return "background-color: #FF5A5F20; font-weight: bold" if p < 0.05 else ""
        except:
            return ""

    styled = df_tests.style \
        .format({
            "Media A": "{:.2f}",
            "Media B": "{:.2f}",
            "Diferencia": "{:.2f}",
            "t-stat": "{:.3f}",
            "p-value": "{:.4f}"
        }) \
        .applymap(highlight_pval, subset=["p-value"])

    st.markdown(f"""
    <div class="table-container">
        <div class="table-title">Resultados de Pruebas t-Student: `{test_var}`</div>
    """, unsafe_allow_html=True)
    st.dataframe(styled, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

  
    # HALLAZGOS CLAVE
   
    significant = df_tests[df_tests["p-value"].apply(lambda x: isinstance(x, float) and x < 0.05)]
    
    st.markdown("## Hallazgos Clave")
    if not significant.empty:
        st.markdown(f"""
        <div class="findings-box">
        <strong>Diferencias estadísticamente significativas (p < 0.05):</strong><br>
        """, unsafe_allow_html=True)
        
        for _, row in significant.iterrows():
            a, b = row["Ciudad A"], row["Ciudad B"]
            diff = row["Diferencia"]
            direction = "mayor" if diff > 0 else "menor"
            st.markdown(f"• **{a}** tiene media **{abs(diff):.2f} {direction}** que **{b}** (p = {row['p-value']:.4f})")
        
        st.markdown("</div>", unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div class="findings-box">
        <strong>No hay diferencias significativas</strong> entre las ciudades para `{test_var}` (p ≥ 0.05 en todas las comparaciones).
        </div>
        """, unsafe_allow_html=True)

    st.caption("**p-value < 0.05** → Rechazamos H₀: las medias son diferentes.")
else:
    st.info("No hay suficientes datos para realizar pruebas t-Student.")