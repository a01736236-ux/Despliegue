# Paginas/4_Modelos_Predictivos.py
import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from scipy.optimize import curve_fit
import pandas as pd
import numpy as np

DATA = st.session_state.data
NUMERIC_VARS = st.session_state.numeric_vars


# CSS PROFESIONAL

st.markdown("""
<style>
    .chart-container {
        background: white;
        padding: 1.5rem;
        border-radius: 16px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.08);
        border: 1px solid #E5E7EB;
        margin: 1.5rem 0;
    }
    .chart-title {
        font-size: 1.3rem;
        font-weight: 600;
        color: #1F2937;
        margin-bottom: 0.5rem;
    }
    .chart-desc {
        font-size: 0.95rem;
        color: #6B7280;
        margin-top: 0.8rem;
        font-style: italic;
        line-height: 1.4;
    }
    .model-info {
        background: #F8FAFC;
        padding: 1rem;
        border-radius: 12px;
        border-left: 4px solid #FF5A5F;
        margin: 1rem 0;
        font-size: 0.95rem;
    }
    .findings-box {
        background: #FFF4F4;
        padding: 1.2rem;
        border-radius: 12px;
        border-left: 5px solid #FF5A5F;
        margin: 1.5rem 0;
        font-size: 0.95rem;
    }
    .sidebar-header {
        background: #FF5A5F;
        color: white;
        padding: 1rem;
        border-radius: 12px 12px 0 0;
        text-align: center;
        font-weight: 600;
        font-size: 1.2rem;
        margin: 0 0.8rem 0.8rem 0.8rem !important;
    }
    .sidebar-section {
        background: white;
        padding: 0.8rem 1rem;
        border-radius: 12px;
        margin: 0 0.8rem 0.8rem 0.8rem !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        border: 1px solid #E5E7EB;
    }
</style>
""", unsafe_allow_html=True)


# SIDEBAR

with st.sidebar:
    st.markdown('<div class="sidebar-header">Modelos Predictivos</div>', unsafe_allow_html=True)

    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Tipo de Análisis**")
    analysis_type = st.selectbox("", ["Regresión Lineal", "Regresión No Lineal"], label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Variable Dependiente (Y)**")
    y_var = st.selectbox("", options=NUMERIC_VARS, index=0, label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)

    x_options = [v for v in NUMERIC_VARS if v != y_var]

    if analysis_type == "Regresión No Lineal":
        st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
        st.markdown("**Variable Independiente (X)**")
        x_var = st.selectbox("", options=x_options, label_visibility="collapsed")
        st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Ciudades a Analizar**")
    cities = st.multiselect("", options=list(DATA.keys()), default=list(DATA.keys())[:2], label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)

if len(cities) == 0:
    st.warning("Selecciona al menos una ciudad.")
    st.stop()


# FUNCIÓN GRÁFICO (SEGURA)

def plot_with_frame(fig, title, description, city, model_type="linear"):
    try:
        key_hash = str(abs(hash(fig.to_json())))[-8:]
    except:
        key_hash = str(abs(hash(f"{city}_{model_type}_{title}")))[-8:]
    chart_key = f"plot_{city}_{model_type}_{key_hash}"

    with st.container():
        st.markdown(f'<div class="chart-container">', unsafe_allow_html=True)
        st.markdown(f'<div class="chart-title">{title}</div>', unsafe_allow_html=True)
        st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False}, key=chart_key)
        st.markdown(f'<div class="chart-desc">{description}</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)


# REGRESIÓN LINEAL

if analysis_type == "Regresión Lineal":
    st.markdown("## Modelos de Regresión Lineal")
    st.markdown("""
    <div class="model-info">
    <strong>Regresión Lineal</strong>: Modela la relación como línea recta.<br>
    • Simple: 1 variable X | Múltiple: varias X<br>
    <strong>R²</strong>: % explicado | <strong>MAE/RMSE</strong>: error promedio.
    </div>
    """, unsafe_allow_html=True)

    reg_type = st.sidebar.selectbox("**Tipo**", ["Simple", "Múltiple"], label_visibility="collapsed")
    if reg_type == "Simple":
        x_vars = [st.sidebar.selectbox("**X**", options=x_options, label_visibility="collapsed")]
    else:
        x_vars = st.sidebar.multiselect("**Variables X**", options=x_options, default=x_options[:2] if len(x_options)>=2 else x_options, label_visibility="collapsed")

    if not x_vars:
        st.warning("Selecciona al menos una X.")
        st.stop()

    results = []
    figures = []

    for city in cities:
        df = DATA[city]
        cols = [y_var] + x_vars
        if not all(c in df.columns for c in cols):
            st.caption(f"**{city}**: Faltan columnas.")
            continue

        df_clean = df[cols].dropna()
        if len(df_clean) < 10:
            st.caption(f"**{city}**: Pocos datos.")
            continue

        X = df_clean[x_vars]
        y = df_clean[y_var]
        model = LinearRegression().fit(X, y)
        y_pred = model.predict(X)

        r2 = r2_score(y, y_pred)
        mae = mean_absolute_error(y, y_pred)
        rmse = np.sqrt(mean_squared_error(y, y_pred))

        results.append({"Ciudad": city, "Tipo": reg_type, "R²": round(r2,4), "MAE": round(mae,2), "RMSE": round(rmse,2), "n": len(df_clean)})

        if reg_type == "Simple":
            fig = go.Figure()
            df_plot = df_clean.sort_values(x_vars[0])
            fig.add_trace(go.Scatter(x=df_plot[x_vars[0]], y=df_plot[y_var], mode='markers', name='Datos', marker=dict(color='#1f77b4', size=9)))
            fig.add_trace(go.Scatter(x=df_plot[x_vars[0]], y=model.predict(df_plot[x_vars]), mode='lines', name='Línea', line=dict(color='#FF5A5F', width=5)))
            fig.update_layout(height=500, template="simple_white")
            figures.append((city, fig, r2, "simple"))
        else:
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=y, y=y_pred, mode='markers', name='Real vs Predicho',
                                    marker=dict(color='#1f77b4', size=9, opacity=0.8),
                                    hovertemplate="<b>Real</b>: %{x:.2f}<br><b>Pred</b>: %{y:.2f}<extra></extra>"))
            lim_min = min(y.min(), y_pred.min()) * 0.95
            lim_max = max(y.max(), y_pred.max()) * 1.05
            fig.add_trace(go.Scatter(x=[lim_min, lim_max], y=[lim_min, lim_max],
                                    mode='lines', name='Perfecto', line=dict(color='#FF5A5F', width=5)))
            fig.update_layout(xaxis_title=f"{y_var} (Real)", yaxis_title=f"{y_var} (Predicho)",
                              height=520, template="simple_white", showlegend=True)
            figures.append((city, fig, r2, "multiple"))

    if figures:
        st.markdown("### Gráficas")
        cols = st.columns(min(3, len(figures)))
        for i, (city, fig, r2, tipo) in enumerate(figures):
            with cols[i % 3]:
                desc = "Línea de ajuste" if tipo == "simple" else "Línea roja = predicción perfecta"
                plot_with_frame(fig, f"{city} | R² = {r2:.4f}", desc, city, tipo)

    if results:
        df_res = pd.DataFrame(results)
        styled = df_res.style.apply(lambda s: ['background:#FF5A5F20; font-weight:bold' if v==s.max() else '' for v in s], subset=['R²'])\
                             .format({"R²":"{:.4f}"})
        st.markdown("### Resultados")
        st.dataframe(styled, use_container_width=True)


# REGRESIÓN NO LINEAL 

else:
    st.markdown("## Regresión No Lineal")

    funcs = {
        "Cuadrática":   lambda x, a, b, c: a*x**2 + b*x + c,
        "Cúbica":       lambda x, a, b, c, d: a*x**3 + b*x**2 + c*x + d,
        "Exponencial":  lambda x, a, b, c: a*np.exp(b*x) + c,
        "Logarítmica":  lambda x, a, b: a*np.log(np.abs(x) + 1e-8) + b,
        "Potencia":     lambda x, a, b: a * (x**b)
    }
    
    model_type = st.sidebar.selectbox("**Función**", list(funcs.keys()), label_visibility="collapsed")
    st.markdown(f"<div class='model-info'><strong>{model_type}</strong>: modelo no lineal</div>", unsafe_allow_html=True)

    results = []
    figures = []

    for city in cities:
        df = DATA[city]
        if x_var not in df.columns or y_var not in df.columns:
            st.caption(f"**{city}**: Faltan variables.")
            continue
            
        d = df[[x_var, y_var]].dropna().copy()
        if len(d) < 15:
            st.caption(f"**{city}**: Muy pocos datos.")
            continue

        x = d[x_var].values
        y = d[y_var].values

        # Filtrar valores problemáticos según el modelo
        if model_type in ["Potencia", "Logarítmica"]:
            mask = (x > 0) if model_type == "Potencia" else (x >= 0)
            x, y = x[mask], y[mask]
            if len(x) < 15:
                st.caption(f"**{city}**: No hay suficientes valores válidos para {model_type}.")
                continue

        try:
            func = funcs[model_type]
            n_params = func.__code__.co_argcount - 1
            p0 = [1.0] * n_params

            # Ajuste con límites para evitar explosiones
            params, _ = curve_fit(
                func, x, y, 
                p0=p0, 
                maxfev=10000,
                bounds=(-1e6, 1e6)  # evita parámetros locos
            )
            y_pred = func(x, *params)

            
            ss_res = np.sum((y - y_pred) ** 2)                    # Suma de residuos
            ss_tot = np.sum((y - np.mean(y)) ** 2)                # Varianza total
            r2 = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0       # R² real
            r2 = max(min(r2, 0.999), -1.0)  # nunca >1 ni muy negativo

            results.append({
                "Ciudad": city,
                "Modelo": model_type,
                "R²": round(r2, 4),
                "n": len(d)
            })

            # Gráfica: puntos reales (azul) + ajuste (rojo relleno)
            df_plot = d.sort_values(x_var).reset_index(drop=True)
            x_plot = df_plot[x_var].values
            y_fit = func(x_plot, *params)

            fig = go.Figure()

            # Datos reales
            fig.add_trace(go.Scatter(
                x=df_plot[x_var], y=df_plot[y_var],
                mode='markers',
                name='Datos reales',
                marker=dict(color='#1f77b4', size=10)
            ))

            
            fig.add_trace(go.Scatter(
                x=x_plot, y=y_fit,
                mode='markers',
                name=f'Ajuste {model_type}',
                marker=dict(color='#FF5A5F', size=10)
            ))

            fig.update_layout(
                height=520,
                template="simple_white",
                showlegend=True,
                legend=dict(yanchor="top", y=0.99, xanchor="left", x=0.01),
                title=f"{city} | {model_type} | R² = {r2:.4f}"
            )

            figures.append((city, fig, r2))

        except Exception as e:
            st.caption(f"**{city}** → {model_type}: no converge")

    # Mostrar resultados
    if figures:
        st.markdown("### Gráficas No Lineales")
        cols = st.columns(min(3, len(figures)))
        for i, (city, fig, r2) in enumerate(figures):
            with cols[i % 3]:
                plot_with_frame(
                    fig,
                    f"{city} | R² = {r2:.4f}",
                    "Azul = datos reales | Rojo = ajuste no lineal",
                    city,
                    model_type
                )

    if results:
        df_res = pd.DataFrame(results)
        styled = df_res.style.apply(
            lambda s: ['background:#FF5A5F20; font-weight:bold' if v == s.max() else '' for v in s],
            subset=['R²']
        ).format({"R²": "{:.4f}"})
        
        st.markdown("### Tabla de Resultados No Lineales")
        st.dataframe(styled, use_container_width=True)

        best = df_res.loc[df_res["R²"].idxmax()]
        st.markdown(f"""
        <div class="findings-box">
        <strong>Mejor modelo no lineal</strong>: <strong>{best['Ciudad']}</strong> → <strong>{best['Modelo']}</strong><br>
        → R² = <strong>{best['R²']:.4f}</strong> (explica el {best['R²']*100:.1f}% de la variación)<br>
        Recomendación: Úsalo para predicciones más precisas que un modelo lineal.
        </div>
        """, unsafe_allow_html=True)