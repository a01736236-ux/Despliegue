# Paginas/6_Exportar.py
import streamlit as st
import pandas as pd
from io import BytesIO
import time

DATA = st.session_state.get("data", {})


# CSS PROFESIONAL

st.markdown("""
<style>
    .export-container {
        background: white;
        padding: 1.8rem;
        border-radius: 16px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.08);
        border: 1px solid #E5E7EB;
        margin: 1.5rem 0;
    }
    .export-title {
        font-size: 1.4rem;
        font-weight: 600;
        color: #1F2937;
        margin-bottom: 0.5rem;
    }
    .export-desc {
        font-size: 0.95rem;
        color: #6B7280;
        margin-top: 0.8rem;
        font-style: italic;
        line-height: 1.4;
    }
    .summary-box {
        background: #F0FDF4;
        padding: 1.2rem;
        border-radius: 12px;
        border-left: 5px solid #22C55E;
        margin: 1.5rem 0;
        font-size: 0.95rem;
    }
    .warning-box {
        background: #FFFBEB;
        padding: 1.2rem;
        border-radius: 12px;
        border-left: 5px solid #F59E0B;
        margin: 1.5rem 0;
        font-size: 0.95rem;
    }
    .sidebar .sidebar-content {
        background: #F9FAFB;
        border-right: 1px solid #E5E7EB;
        padding: 0 !important;
    }
    .sidebar-header {
        background: #FF5A5F;
        color: white;
        padding: 1rem;
        border-radius: 12px 12px 0 0;
        text-align: center;
        font-weight: 600;
        font-size: 1.2rem;
        margin: 0 0.8rem 0.8rem 0.8rem !important;
    }
    .sidebar-section {
        background: white;
        padding: 0.8rem 1rem;
        border-radius: 12px;
        margin: 0 0.8rem 0.8rem 0.8rem !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        border: 1px solid #E5E7EB;
    }
    .stDownloadButton > button {
        background: #FF5A5F;
        color: white;
        border: none;
        padding: 0.6rem 1.2rem;
        border-radius: 8px;
        font-weight: 500;
        font-size: 1rem;
    }
    .stDownloadButton > button:hover {
        background: #E31C79;
    }
</style>
""", unsafe_allow_html=True)

# SIDEBAR PROFESIONAL

with st.sidebar:
    st.markdown('<div class="sidebar-header">Exportar Datos</div>', unsafe_allow_html=True)

    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Ciudad a Analizar**")
    export_city = st.selectbox("", options=list(DATA.keys()), index=0, label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Variable Categórica**")
    st.caption("Elige para frecuencias")
    export_var = st.selectbox("", options=[
        "room_type", "neighbourhood_group_cleansed", "host_is_superhost", "property_type"
    ], index=0, label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)


# TÍTULO PRINCIPAL

st.markdown("# Exportar Resultados")


# ANÁLISIS DE CIUDAD SELECCIONADA

df = DATA[export_city]

st.markdown(f"## Análisis: **{export_city}**")

# --- FRECUENCIAS ---
if export_var in df.columns:
    freq = df[export_var].value_counts().reset_index()
    freq.columns = ["Categoría", "Frecuencia"]
    freq["% del Total"] = (freq["Frecuencia"] / len(df) * 100).round(2)

    with st.container():
        st.markdown('<div class="export-container">', unsafe_allow_html=True)
        st.markdown(f'<div class="export-title">Frecuencia de `{export_var}`</div>', unsafe_allow_html=True)
        st.dataframe(freq, use_container_width=True)
        st.markdown(f'<div class="export-desc">Total de listados: {len(df):,} | Variable: `{export_var}`</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)

    # --- EXPORTAR ---
    col1, col2, col3 = st.columns([1, 1, 2])
    with col1:
        csv = freq.to_csv(index=False).encode('utf-8')
        st.download_button(
            label="Descargar CSV",
            data=csv,
            file_name=f"{export_city}_{export_var}_frecuencias.csv",
            mime="text/csv",
            key="csv"
        )
    with col2:
        # USAMOS openpyxl (incluido con pandas)
        output = BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            freq.to_excel(writer, index=False, sheet_name='Frecuencias')
        excel_data = output.getvalue()
        st.download_button(
            label="Descargar Excel",
            data=excel_data,
            file_name=f"{export_city}_{export_var}_frecuencias.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            key="excel"
        )
    with col3:
        placeholder = st.empty()
        if st.button("Exportar Ahora", key="export_now"):
            with st.spinner(f"Exportando datos de **{export_city}**..."):
                time.sleep(1.5)
            placeholder.success(f"Exportación completada: `{export_city}_{export_var}_frecuencias.*`")
else:
    st.warning(f"La variable `{export_var}` no existe en **{export_city}**.")


# TABLAS ESENCIALES POR CIUDAD

st.markdown("## Tablas Clave por Ciudad")

summary_data = []
essential_tables = {}

for city, df_city in DATA.items():
    row = {"Ciudad": city}
    
    # Total listados
    row["Total Listados"] = len(df_city)
    
    # Precio promedio (si existe)
    if "price" in df_city.columns:
        try:
            price_clean = pd.to_numeric(df_city["price"].astype(str).str.replace(r"[\$,]", "", regex=True), errors='coerce')
            row["Precio Promedio"] = f"${price_clean.mean():.2f}" if not price_clean.isna().all() else "N/D"
        except:
            row["Precio Promedio"] = "N/D"
    else:
        row["Precio Promedio"] = "N/D"
    
    # Tipo de habitación más común
    if "room_type" in df_city.columns:
        row["Hab. Más Común"] = df_city["room_type"].mode().iloc[0] if not df_city["room_type"].mode().empty else "N/D"
    else:
        row["Hab. Más Común"] = "N/D"
    
    # Superhost
    if "host_is_superhost" in df_city.columns:
        superhost_pct = (df_city["host_is_superhost"] == 't').mean() * 100
        row["% Superhost"] = f"{superhost_pct:.1f}%"
    else:
        row["% Superhost"] = "N/D"
    
    summary_data.append(row)

    # Guardar tabla esencial
    if export_var in df_city.columns:
        freq_city = df_city[export_var].value_counts().reset_index()
        freq_city.columns = ["Categoría", "Frecuencia"]
        freq_city["%"] = (freq_city["Frecuencia"] / len(df_city) * 100).round(2)
        essential_tables[city] = freq_city

# --- RESUMEN EJECUTIVO ---
summary_df = pd.DataFrame(summary_data)
st.markdown('<div class="summary-box">', unsafe_allow_html=True)
st.markdown("### Resumen Ejecutivo de Ciudades")
st.dataframe(summary_df, use_container_width=True)
st.markdown('</div>', unsafe_allow_html=True)

# --- TABLAS ESENCIALES ---
st.markdown("### Frecuencias por Ciudad")
for city, table in essential_tables.items():
    with st.expander(f"{city} — `{export_var}` ({len(table)} categorías)"):
        st.dataframe(table, use_container_width=True)

# --- EXPORTAR TODO ---
st.markdown("## Exportar Todo")
if st.button("Descargar Informe Completo (Excel)", type="primary"):
    with st.spinner("Generando informe completo..."):
        output = BytesIO()
        with pd.ExcelWriter(output, engine='openpyxl') as writer:
            summary_df.to_excel(writer, index=False, sheet_name='Resumen')
            for city, table in essential_tables.items():
                safe_city = city.replace("/", "_")[:30]
                table.to_excel(writer, index=False, sheet_name=safe_city)
        excel_all = output.getvalue()
    
    st.success("Informe completo generado")
    st.download_button(
        label="Descargar Informe Completo",
        data=excel_all,
        file_name=f"Informe_Airbnb_{pd.Timestamp.now().strftime('%Y%m%d')}.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

# --- INFO FINAL ---
st.caption("**Nota**: Usa `openpyxl` (incluido con pandas). No requiere instalación extra.")