# Paginas/5_Correlaciones.py
import streamlit as st
import plotly.express as px
import pandas as pd
import numpy as np

DATA = st.session_state.data
NUMERIC_VARS = st.session_state.get("numeric_vars", [])


# CSS PROFESIONAL + BOTÓN AMPLIAR

st.markdown("""
<style>
    .chart-container {
        background: white;
        padding: 1.5rem;
        border-radius: 16px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.08);
        border: 1px solid #E5E7EB;
        margin: 1.5rem 0;
    }
    .chart-title {
        font-size: 1.3rem;
        font-weight: 600;
        color: #1F2937;
        margin-bottom: 0.5rem;
    }
    .chart-desc {
        font-size: 0.95rem;
        color: #6B7280;
        margin-top: 0.8rem;
        font-style: italic;
        line-height: 1.4;
    }
    .findings-box {
        background: #FFF4F4;
        padding: 1.2rem;
        border-radius: 12px;
        border-left: 5px solid #FF5A5F;
        margin: 1.5rem 0;
        font-size: 0.95rem;
    }
    .sidebar .sidebar-content {
        background: #F9FAFB;
        border-right: 1px solid #E5E7EB;
        padding: 0 !important;
    }
    .sidebar-header {
        background: #FF5A5F;
        color: white;
        padding: 1rem;
        border-radius: 12px 12px 0 0;
        text-align: center;
        font-weight: 600;
        font-size: 1.2rem;
        margin: 0 0.8rem 0.8rem 0.8rem !important;
    }
    .sidebar-section {
        background: white;
        padding: 0.8rem 1rem;
        border-radius: 12px;
        margin: 0 0.8rem 0.8rem 0.8rem !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        border: 1px solid #E5E7EB;
    }
    .sidebar .stMultiselect > div {
        margin: 0 !important;
        padding: 0.4rem 0 !important;
    }
    .expand-btn {
        background: #FF5A5F;
        color: white;
        border: none;
        padding: 0.4rem 0.8rem;
        border-radius: 8px;
        font-weight: 500;
        font-size: 0.9rem;
        margin-left: 0.5rem;
        cursor: pointer;
    }
    .expand-btn:hover {
        background: #E31C79;
    }
</style>
""", unsafe_allow_html=True)


# SIDEBAR PROFESIONAL

with st.sidebar:
    st.markdown('<div class="sidebar-header">Correlaciones</div>', unsafe_allow_html=True)

    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Variables Numéricas**")
    st.caption("Selecciona al menos 2")
    corr_vars = st.multiselect("", options=NUMERIC_VARS, default=NUMERIC_VARS[:3] if len(NUMERIC_VARS) >= 3 else NUMERIC_VARS, label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)

    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Ciudades**")
    st.caption("Máximo 3")
    cities = st.multiselect("", options=list(DATA.keys()), default=list(DATA.keys())[:2], label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)


# VALIDACIÓN

if len(corr_vars) < 2:
    st.warning("Selecciona al menos 2 variables numéricas.")
    st.stop()

if len(cities) == 0:
    st.warning("Selecciona al menos una ciudad.")
    st.stop()


# FUNCIÓN PARA GRÁFICO CON BOTÓN AMPLIAR

def plot_corr_matrix(fig, title, city_idx, n_rows):
    col1, col2 = st.columns([1, 0.1])
    with col1:
        with st.container():
            st.markdown(f'<div class="chart-container">', unsafe_allow_html=True)
            st.markdown(f'<div class="chart-title">{title}</div>', unsafe_allow_html=True)
            st.plotly_chart(
                fig,
                use_container_width=True,
                config={
                    'displayModeBar': True,
                    'modeBarButtonsToAdd': ['drawline', 'drawrect', 'erasetool'],
                    'toImageButtonOptions': {'format': 'png', 'filename': f'correlacion_{title}'}
                },
                key=f"corr_{city_idx}"
            )
            st.markdown(f'<div class="chart-desc">n={n_rows} filas válidas. |r| ≥ 0.7 = fuerte.</div>', unsafe_allow_html=True)
            st.markdown('</div>', unsafe_allow_html=True)
    with col2:
        if st.button("Ampliar", key=f"expand_{city_idx}", help="Ver gráfica completa"):
            st.plotly_chart(
                fig,
                use_container_width=True,
                height=800,
                config={
                    'displayModeBar': True,
                    'modeBarButtonsToAdd': ['drawline', 'drawrect', 'erasetool'],
                    'toImageButtonOptions': {'format': 'png', 'filename': f'correlacion_{title}'}
                },
                key=f"expanded_{city_idx}"
            )


# MATRICES DE CORRELACIÓN

st.markdown("## Matrices de Correlación")

figures = []
all_corrs = {}

for city_idx, city in enumerate(cities):
    df = DATA[city]
    available = [v for v in corr_vars if v in df.columns]
    if len(available) < 2:
        st.caption(f"**{city}**: Faltan variables.")
        continue

    # --- CONVERSIÓN ROBUSTA ---
    df_num = df[available].apply(pd.to_numeric, errors='coerce')
    df_num = df_num.dropna(how='all')  # Solo elimina si TODO es NaN

    if len(df_num) < 2:
        st.caption(f"**{city}**: Insuficientes filas válidas (n={len(df_num)}).")
        continue

    # Filtrar variables con al menos 10 datos
    valid_vars = [col for col in df_num.columns if df_num[col].count() >= 10]
    if len(valid_vars) < 2:
        st.caption(f"**{city}**: Ninguna variable con suficientes datos.")
        continue

    df_num = df_num[valid_vars]
    corr = df_num.corr()
    all_corrs[city] = (corr, len(df_num))

    # --- GRÁFICO ---
    fig = px.imshow(
        corr,
        text_auto=".2f",
        color_continuous_scale="RdBu",
        zmin=-1, zmax=1,
        aspect="auto",
        title=f"Correlación: {city}"
    )
    fig.update_layout(
        height=400 + 50 * len(valid_vars),
        margin=dict(l=40, r=40, t=60, b=40)
    )
    figures.append((city, fig, city_idx, len(df_num)))

# --- MOSTRAR GRÁFICOS ---
n_cols = max(1, min(len(figures), 3))
cols = st.columns(n_cols)
for city, fig, city_idx, n_rows in figures:
    with cols[city_idx % n_cols]:
        plot_corr_matrix(fig, f"Correlación: {city}", city_idx, n_rows)


# HALLAZGOS CLAVE

if all_corrs:
    st.markdown("## Hallazgos Clave")

    strong_pairs = []
    for city, (corr, n_rows) in all_corrs.items():
        for i in range(len(corr)):
            for j in range(i + 1, len(corr)):
                var1, var2 = corr.index[i], corr.columns[j]
                r = corr.iloc[i, j]
                if abs(r) >= 0.7:
                    direction = "positiva" if r > 0 else "negativa"
                    strong_pairs.append({
                        "Ciudad": city,
                        "Variables": f"`{var1}` ↔ `{var2}`",
                        "r": round(r, 3),
                        "Tipo": direction,
                        "n": n_rows
                    })

    if strong_pairs:
        df_strong = pd.DataFrame(strong_pairs).sort_values("r", key=abs, ascending=False)
        
        st.markdown(f"""
        <div class="findings-box">
        <strong>Correlaciones fuertes detectadas (|r| ≥ 0.7):</strong><br>
        """, unsafe_allow_html=True)
        
        for _, row in df_strong.iterrows():
            st.markdown(f"• **{row['Ciudad']}** (n={row['n']}): {row['Variables']} → **r = {row['r']}** ({row['Tipo']})")
        
        st.markdown("</div>", unsafe_allow_html=True)
        
        st.caption("**Interpretación**: |r| ≥ 0.7 = relación fuerte. Evita usar variables correlacionadas en modelos.")
    else:
        st.markdown(f"""
        <div class="findings-box">
        <strong>No hay correlaciones fuertes</strong> (|r| < 0.7) entre las variables seleccionadas.
        </div>
        """, unsafe_allow_html=True)
else:
    st.info("No hay datos suficientes para calcular correlaciones.")