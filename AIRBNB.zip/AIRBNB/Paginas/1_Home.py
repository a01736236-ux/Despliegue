# Paginas/1_Home.py
import streamlit as st
import plotly.express as px
import pandas as pd


# CSS PROFESIONAL

st.markdown("""
<style>
    .main-title {
        font-size: 2.8rem;
        font-weight: 700;
        text-align: center;
        color: #FF5A5F;
        margin-bottom: 1rem;
    }
    .subtitle {
        font-size: 1.5rem;
        text-align: center;
        color: #555;
        margin-bottom: 2rem;
    }
    .card {
        background: white;
        padding: 1.5rem;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        margin: 1rem 0;
        border: 1px solid #eee;
    }
    .city-badge {
        background: #FF5A5F;
        color: white;
        padding: 0.3rem 0.8rem;
        border-radius: 20px;
        font-size: 0.9rem;
        font-weight: bold;
    }
    .highlight {
        background: #FFF4F4;
        padding: 1rem;
        border-left: 5px solid #FF5A5F;
        border-radius: 0 8px 8px 0;
        margin: 1rem 0;
    }
    .footer {
        text-align: center;
        margin-top: 3rem;
        color: #888;
        font-size: 0.9rem;
    }
</style>
""", unsafe_allow_html=True)


# TÍTULO PRINCIPAL

st.markdown('<div class="main-title">Airbnb Analytics Pro</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">Análisis Avanzado de Alojamiento Vacacional en 5 Ciudades</div>', unsafe_allow_html=True)


# IMAGEN GRANDE

st.image(
    "https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/Airbnb_Logo_B%C3%A9lo.svg/2560px-Airbnb_Logo_B%C3%A9lo.svg.png",
    width=300,
    use_column_width=False
)
st.markdown("<br>", unsafe_allow_html=True)


# INTRODUCCIÓN

st.markdown("""
<div class="card">
<strong>Bienvenido al dashboard interactivo de Airbnb</strong><br>
Explora <strong>7.7 millones de listados globales</strong> y descubre tendencias en <strong>Ámsterdam, Bérgamo, Oporto, Albany y Berlín</strong>.  
Con un mercado que genera <strong>$81 mil millones en 2024</strong>, este análisis te ayuda a tomar decisiones basadas en datos.
</div>
""", unsafe_allow_html=True)


# FUNCIONALIDADES

st.markdown("## ¿Qué puedes hacer?")
cols = st.columns(3)
features = [
    ("Visualizaciones", "Treemaps, barras, tortas y boxplots para entender distribuciones y comparaciones."),
    ("Pruebas Estadísticas", "t-Student entre ciudades. p < 0.05 = diferencia significativa."),
    ("Modelos Predictivos", "Regresión lineal y no lineal (5 funciones). Predice precios con R²."),
    ("Correlaciones", "Matriz de Pearson: rojo = relación positiva, azul = negativa."),
    ("Exportar", "Descarga tablas y gráficos en CSV para informes."),
]
for i, (title, desc) in enumerate(features):
    with cols[i % 3]:
        st.markdown(f"""
        <div class="card">
            <h4>{title}</h4>
            <p style="font-size:0.95rem; color:#555">{desc}</p>
        </div>
        """, unsafe_allow_html=True)


# DATOS INTERESANTES

st.markdown("## Datos Clave de las Ciudades (2023-2024)")
data = {
    "Ciudad": ["Ámsterdam", "Bérgamo", "Oporto", "Albany", "Berlín"],
    "Listados": ["~100,000", "~5,000", "~15,000", "~2,500", "~14,000"],
    "Precio Nocturno": ["$158", "$95", "$90", "$85", "$110"],
    "Ocupación": ["70%", "65%", "68%", "60%", "72%"],
    "Crecimiento": ["+12%", "+8%", "+10%", "+6%", "+11%"],
    "Turistas por Habitante": ["12", "2", "10", "1.5", "4"]
}
df_stats = pd.DataFrame(data)

# Resaltar la más concurrida
def highlight_concurrent(row):
    return ['background-color: #FFEBEB' if row["Turistas por Habitante"] == "12" else '' for _ in row]

styled = df_stats.style \
    .apply(highlight_concurrent, axis=1) \
    .format({"Precio Nocturno": "${}", "Ocupación": "{}"})

st.dataframe(styled, use_container_width=True)

st.markdown("""
<div class="highlight">
<strong>Ámsterdam es la más concurrida</strong>: 12 turistas por habitante (Holidu 2024).  
<strong>Berlín y Oporto</strong> siguen con alta densidad.  
<strong>Bérgamo y Albany</strong>: ideales para experiencias tranquilas.
</div>
""", unsafe_allow_html=True)


# MAPAS GEOGRÁFICOS

st.markdown("## Mapas Turísticos Interactivos")
maps = {
    "Ámsterdam": {"lat": 52.3676, "lon": 4.9041, "zoom": 11, "top": ["Canales", "Rijksmuseum", "Vondelpark"]},
    "Bérgamo": {"lat": 45.6983, "lon": 9.6773, "zoom": 12, "top": ["Ciudad Alta", "Accademia Carrara", "Funicular"]},
    "Oporto": {"lat": 41.1579, "lon": -8.6291, "zoom": 12, "top": ["Ribeira", "Librería Lello", "Puente Dom Luís"]},
    "Albany": {"lat": 42.6526, "lon": -73.7562, "zoom": 12, "top": ["Capitolio", "Hudson River", "Albany Institute"]},
    "Berlín": {"lat": 52.5200, "lon": 13.4050, "zoom": 11, "top": ["Muro", "Brandemburgo", "Isla de Museos"]}
}

cols = st.columns(3)
for idx, (city, info) in enumerate(maps.items()):
    with cols[idx % 3]:
        fig = px.scatter_mapbox(
            lat=[info["lat"]], lon=[info["lon"]],
            zoom=info["zoom"],
            height=300,
            center=dict(lat=info["lat"], lon=info["lon"]),
            hover_name=[city],
            title=f"<b>{city}</b>"
        )
        fig.update_layout(
            mapbox_style="carto-positron",
            margin=dict(l=0, r=0, t=40, b=0),
            title_x=0.5
        )
        st.plotly_chart(fig, use_container_width=True)
        st.markdown(f"**Top 3**: {', '.join(info['top'])}")


# CONCURSO TURÍSTICO

st.markdown("## ¿Dónde hay más multitudes?")
st.markdown("""
<div class="card">
<strong>Ranking de saturación turística (turistas por habitante):</strong><br>
1. <span class="city-badge">Ámsterdam</span> → 12 (¡la más sobrecargada de Europa!)<br>
2. <span class="city-badge">Oporto</span> → 10<br>
3. <span class="city-badge">Berlín</span> → 4<br>
4. <span class="city-badge">Bérgamo</span> → 2<br>
5. <span class="city-badge">Albany</span> → 1.5<br><br>

<strong>Consejo</strong>: Visita en <strong>primavera (abril-mayo)</strong> para evitar multitudes.  
Ámsterdam genera <strong>$85B en impacto económico</strong>, pero Bérgamo ofrece autenticidad.
</div>
""", unsafe_allow_html=True)


# FOOTER

st.markdown("""
<div class="footer">
    <strong>Airbnb Analytics Pro</strong> • Datos: Inside Airbnb, Statista, Holidu 2024<br>
    Carga tus propios CSVs en <code>data/</code> • ¡Explora y descubre!
</div>
""", unsafe_allow_html=True)