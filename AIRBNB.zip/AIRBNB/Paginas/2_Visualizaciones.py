# Paginas/2_Visualizaciones.py
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np

DATA = st.session_state.data
CATEGORICAL_VARS = st.session_state.categorical_vars
NUMERIC_VARS = st.session_state.numeric_vars


# CSS ULTRA COMPACTO Y PROFESIONAL

st.markdown("""
<style>
    .chart-container {
        background: white;
        padding: 1.5rem;
        border-radius: 16px;
        box-shadow: 0 4px 16px rgba(0,0,0,0.08);
        border: 1px solid #E5E7EB;
        margin: 1.5rem 0;
    }
    .chart-title {
        font-size: 1.3rem;
        font-weight: 600;
        color: #1F2937;
        margin-bottom: 0.5rem;
    }
    .chart-desc {
        font-size: 0.95rem;
        color: #6B7280;
        margin-top: 0.8rem;
        font-style: italic;
        line-height: 1.4;
    }

    /* SIDEBAR COMPACTO */
    .sidebar .sidebar-content {
        background: #F9FAFB;
        border-right: 1px solid #E5E7EB;
        padding: 0 !important;
        margin: 0 !important;
    }
    .sidebar-header {
        background: #FF5A5F;
        color: white;
        padding: 1rem;
        border-radius: 12px 12px 0 0;
        text-align: center;
        font-weight: 600;
        font-size: 1.2rem;
        margin: 0 0.8rem 0.8rem 0.8rem !important;
    }
    .sidebar-section {
        background: white;
        padding: 0.8rem 1rem;
        border-radius: 12px;
        margin: 0 0.8rem 0.8rem 0.8rem !important;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        border: 1px solid #E5E7EB;
    }
    .sidebar-label {
        font-weight: 600;
        color: #374151;
        font-size: 1rem;
        margin: 0 0 0.5rem 0;
    }
    .sidebar .stSelectbox > div > div,
    .sidebar .stSlider > div,
    .sidebar .stMultiselect > div,
    .sidebar .stButton > button {
        margin: 0 !important;
        padding: 0.4rem 0 !important;
    }
    .sidebar .stButton > button {
        height: 2.2rem !important;
    }
</style>
""", unsafe_allow_html=True)


# SIDEBAR ULTRA COMPACTO

with st.sidebar:
    st.markdown('<div class="sidebar-header">Visualizaciones</div>', unsafe_allow_html=True)

    # Ciudad principal
    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Ciudad Principal**", unsafe_allow_html=True)
    primary_city = st.selectbox("", options=list(DATA.keys()), label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)

    # Variable categórica
    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Variable Categórica**", unsafe_allow_html=True)
    var_cat = st.selectbox("", options=CATEGORICAL_VARS, label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)

    # Top K
    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Top K**", unsafe_allow_html=True)
    top_k = st.slider("", 5, 30, 10, label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)

    # Comparar ciudades
    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Comparar Ciudades**", unsafe_allow_html=True)
    compare_list = st.session_state.get("compare_list", [])
    multisel = st.multiselect("", options=list(DATA.keys()), default=compare_list, label_visibility="collapsed")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("Agregar", use_container_width=True):
            for c in multisel:
                if c not in compare_list:
                    compare_list.append(c)
            st.session_state.compare_list = compare_list
    with col2:
        if st.button("Limpiar", use_container_width=True):
            st.session_state.compare_list = []

    if compare_list:
        st.markdown("**Activas:**")
        for c in compare_list:
            st.markdown(f"• {c}")
    else:
        st.caption("Ninguna activa")

    cities_compare = compare_list if compare_list else st.multiselect(
        "", options=list(DATA.keys()), default=[primary_city], label_visibility="collapsed"
    )
    st.markdown('</div>', unsafe_allow_html=True)

    # Boxplots
    st.markdown('<div class="sidebar-section">', unsafe_allow_html=True)
    st.markdown("**Boxplots**", unsafe_allow_html=True)
    default_num = [v for v in ["price_numeric", "availability_365", "review_scores_value"] if v in NUMERIC_VARS][:3]
    num_vars = st.multiselect("", options=NUMERIC_VARS, default=default_num, label_visibility="collapsed")
    st.markdown('</div>', unsafe_allow_html=True)


# FUNCIÓN DE GRÁFICO CON MARCO

def plot_with_frame(fig, title, description):
    with st.container():
        st.markdown(f'<div class="chart-container">', unsafe_allow_html=True)
        st.markdown(f'<div class="chart-title">{title}</div>', unsafe_allow_html=True)
        st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})
        st.markdown(f'<div class="chart-desc">{description}</div>', unsafe_allow_html=True)
        st.markdown('</div>', unsafe_allow_html=True)


# 1. TREEMAP

st.markdown("## Análisis de Distribución Categórica")
df_primary = DATA[primary_city]

if var_cat not in df_primary.columns:
    st.error(f"Variable `{var_cat}` no existe en {primary_city}.")
elif df_primary[var_cat].isna().all():
    st.warning(f"Todos los valores de `{var_cat}` son nulos en {primary_city}.")
else:
    freq_series = df_primary[var_cat].value_counts().head(top_k)
    if freq_series.empty:
        st.info(f"No hay suficientes datos para `{var_cat}` en {primary_city}.")
    else:
        treemap_df = freq_series.reset_index()
        treemap_df.columns = ["categoria", "frecuencia"]
        fig_tree = px.treemap(
            treemap_df, path=["categoria"], values="frecuencia",
            color="frecuencia", color_continuous_scale="Reds"
        )
        fig_tree.update_layout(height=500, margin=dict(t=50, b=20, l=20, r=20), title_text="")
        plot_with_frame(
            fig_tree,
            f"Jerarquía de {var_cat} en {primary_city}",
            f"Muestra las {top_k} categorías más frecuentes en una estructura jerárquica."
        )


# 2. BARRAS AGRUPADAS

if not cities_compare:
    st.warning("Selecciona al menos una ciudad para comparar.")
else:
    freqs = []
    for c in cities_compare:
        df = DATA[c]
        if var_cat in df.columns and not df[var_cat].isna().all():
            f = df[var_cat].value_counts().reset_index()
            f.columns = ["categoria", "frecuencia"]
            f["city"] = c
            freqs.append(f)
    
    if freqs:
        freq_all = pd.concat(freqs)
        top_global = freq_all.groupby("categoria")["frecuencia"].sum().sort_values(ascending=False).head(top_k).index
        freq_comp = freq_all[freq_all["categoria"].isin(top_global)]
        
        if not freq_comp.empty:
            fig_bar = px.bar(
                freq_comp, x="categoria", y="frecuencia", color="city",
                barmode="group",
                color_discrete_sequence=px.colors.qualitative.Set2
            )
            fig_bar.update_layout(xaxis_tickangle=-45, height=500, legend_title="Ciudad", title_text="")
            plot_with_frame(
                fig_bar,
                f"Comparación de {var_cat} entre ciudades",
                f"Compara la frecuencia de las {top_k} categorías más comunes."
            )
        else:
            st.info("No hay datos comunes.")
    else:
        st.info("No hay datos válidos.")


# 3. TORTAS

pies = []
for c in cities_compare:
    df = DATA[c]
    if var_cat in df.columns and not df[var_cat].isna().all():
        f = df[var_cat].value_counts().head(top_k).reset_index()
        if not f.empty:
            f.columns = ["categoria", "frecuencia"]
            f["city"] = c
            pies.append(f)

if pies:
    pies_df = pd.concat(pies)
    fig = go.Figure()
    cities = pies_df["city"].unique()
    cols = 3
    rows = (len(cities) + cols - 1) // cols
    colors = px.colors.sequential.Reds
    
    for idx, city in enumerate(cities):
        city_data = pies_df[pies_df["city"] == city]
        if city_data.empty:
            continue
        row = (idx // cols) + 1
        col = (idx % cols) + 1
        fig.add_trace(go.Pie(
            labels=city_data["categoria"], values=city_data["frecuencia"],
            name=city, hole=0.4, marker=dict(colors=colors),
            domain={'x': [(col-1)/cols, col/cols], 'y': [(rows-row)/rows, (rows-row+1)/rows]}
        ))
        fig.add_annotation(
            x=(col - 0.5) / cols, y=(rows - row + 0.9) / rows,
            xref="paper", yref="paper", text=f"<b>{city}</b>",
            showarrow=False, font=dict(size=13, color="#1F2937")
        )
    
    fig.update_layout(
        height=300 + 180 * rows, margin=dict(t=80, b=20),
        showlegend=False, title_text=""
    )
    plot_with_frame(
        fig,
        "Distribución Proporcional por Ciudad",
        f"Visualiza la composición porcentual de las {top_k} categorías."
    )


# 4. BOXPLOTS

if num_vars:
    plot_data = []
    for c in cities_compare:
        df = DATA[c]
        cols = [v for v in num_vars if v in df.columns and df[v].notna().any()]
        if cols:
            temp = df[cols].copy()
            temp["city"] = c
            plot_data.append(temp)
    
    if plot_data:
        combined = pd.concat(plot_data)
        melted = combined.melt(id_vars="city", value_vars=num_vars, var_name="variable", value_name="valor")
        melted = melted.dropna(subset=["valor"])
        
        if not melted.empty:
            fig_box = px.box(
                melted, x="city", y="valor", color="city",
                facet_row="variable", height=300 + 200 * len(num_vars),
                color_discrete_sequence=px.colors.qualitative.Set1
            )
            fig_box.update_yaxes(matches=None)
            fig_box.for_each_annotation(lambda a: a.update(text=a.text.split("=")[-1]))
            fig_box.update_layout(title_text="")
            plot_with_frame(
                fig_box,
                "Distribución de Variables Numéricas",
                f"Compara mediana, dispersión y valores atípicos entre ciudades."
            )
        else:
            st.info("No hay datos numéricos válidos.")