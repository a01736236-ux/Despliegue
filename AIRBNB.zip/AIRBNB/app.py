# app.py
import streamlit as st
from pathlib import Path
import pandas as pd
import numpy as np


# CONFIGURACIÓN DE PÁGINA

st.set_page_config(
    page_title="Airbnb Analytics Pro",
    layout="wide",
    initial_sidebar_state="expanded"
)


# CSS PROFESIONAL PARA SIDEBAR

st.markdown("""
<style>
    .sidebar .sidebar-content {
        background: linear-gradient(180deg, #FF5A5F 0%, #FF385C 100%);
        color: white;
        padding: 1rem;
    }
    .sidebar-header {
        text-align: center;
        margin-bottom: 1.5rem;
    }
    .sidebar-title {
        font-size: 1.8rem;
        font-weight: 700;
        color: white;
        margin: 0.5rem 0;
    }
    .sidebar-subtitle {
        font-size: 1rem;
        color: #FFF0F0;
        margin: 0;
        font-weight: 300;
    }
    .sidebar-img {
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        margin: 1rem 0;
    }
    .nav-item {
        font-size: 1.1rem;
        font-weight: 500;
        color: white !important;
        padding: 0.5rem 0;
    }
    .nav-item:hover {
        color: #FFD1D1 !important;
    }
</style>
""", unsafe_allow_html=True)


# SIDEBAR CON IMAGEN + DISEÑO

with st.sidebar:
    st.markdown("""
    <div class="sidebar-header">
        <img src="https://lauranoesta.com/wp-content/uploads/2019/09/airbnb-logo.png" 
             width="180" class="sidebar-img">
        <h1 class="sidebar-title">Airbnb Analytics</h1>
        <p class="sidebar-subtitle">Análisis Inteligente de Alojamientos</p>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")

    # Info rápida
    st.markdown("**Ciudades analizadas**")
    st.markdown("""
    - Ámsterdam  
    - Bérgamo  
    - Oporto  
    - Albany  
    - Berlín  
    """)

    st.markdown("**Datos**")
    st.markdown("Inside Airbnb • 2023-2024")

    st.markdown("---")


# ENCONTRAR CARPETA 

def find_data_folder():
    current_dir = Path(__file__).parent
    data_path = current_dir / "data"
    if data_path.exists():
        return data_path
    data_path = Path.cwd() / "data"
    if data_path.exists():
        return data_path
    st.warning("Carpeta `data/` no encontrada. Creando con datos de prueba...")
    data_path = current_dir / "data"
    data_path.mkdir(exist_ok=True)
    create_sample_data(data_path)
    return data_path

def create_sample_data(data_path):
    sample_data = {
        "Amsterdam.csv": """id,name,host_id,neighbourhood_group_cleansed,room_type,price,accommodates,bedrooms,has_availability,host_is_superhost
1,"Cozy Apt",1001,"Centrum","Entire home/apt","$100",2,1,t,t
2,"Studio",1002,"West","Private room","$80",1,1,t,f
3,"Luxury",1003,"Oost","Entire home/apt","$200",4,2,t,t
4,"Budget Room",1004,"Noord","Private room","$60",1,1,t,f
5,"Penthouse",1005,"Zuid","Entire home/apt","$300",6,3,t,t""",
        "Bergamo.csv": """id,name,price,accommodates,bedrooms,room_type
1,"Old Town Flat","$120",3,1,"Entire home/apt"
2,"Modern Apt","$95",2,1,"Private room"
3,"Villa","$250",6,3,"Entire home/apt"
4,"Studio","$80",1,1,"Private room\"""",
        "oporto.csv": """id,name,room_type,price,accommodates,host_is_superhost
1,"Ribeira View","Entire home/apt","$90",2,t
2,"Beach Studio","Private room","$70",1,f
3,"Downtown","Entire home/apt","$110",3,t""",
        "albany.csv": """id,name,price,bedrooms,host_is_superhost
1,"Downtown Studio","$85",1,f
2,"Family Home","$150",3,t
3,"Cozy Room","$65",1,f""",
        "berlin.csv": """id,name,price,review_scores_value,accommodates,host_is_superhost
1,"Mitte Loft","$110",8.5,2,t
2,"Kreuzberg","$95",9.0,2,f
3,"Prenzlauer","$130",9.2,3,t"""
    }
    for filename, content in sample_data.items():
        with open(data_path / filename, "w") as f:
            f.write(content.strip())
    st.success(f"Datos de prueba creados en: `{data_path}`")


# CARGAR DATOS

data_dir = find_data_folder()
st.sidebar.success(f"Datos desde: `{data_dir.name}`")

@st.cache_resource
def load_all_data():
    files = {
        "Ámsterdam": "Amsterdam.csv",
        "Bérgamo": "Bergamo.csv",
        "Oporto": "oporto.csv",
        "Albany": "albany.csv",
        "Berlín": "berlin.csv"
    }
    data = {}
    for city, file in files.items():
        path = data_dir / file
        if not path.exists():
            st.error(f"Falta: `{file}`")
            st.stop()
        df = pd.read_csv(path)
        df = df.fillna(method="bfill").fillna(method="ffill")
        if "price" in df.columns:
            df["price_numeric"] = (
                df["price"].astype(str)
                .str.replace(r"[^0-9\.\-]", "", regex=True)
                .replace("", np.nan)
                .astype(float)
            )
        else:
            df["price_numeric"] = np.nan
        data[city] = df
    return data

DATA = load_all_data()


# INICIALIZAR SESSION STATE

if "compare_list" not in st.session_state:
    st.session_state.compare_list = []

st.session_state.data = DATA


# DETECTAR VARIABLES

def get_numeric_vars():
    all_numeric = set()
    for df in DATA.values():
        num_cols = df.select_dtypes(include=[np.number]).columns
        all_numeric.update(num_cols)
    return sorted(all_numeric)

NUMERIC_VARS = get_numeric_vars()


# VARIABLES CATEGÓRICAS

CATEGORICAL_VARS = [
    "neighbourhood_group_cleansed", "last_scraped", "has_availability", "host_is_superhost",
    "host_has_profile_pic", "host_identity_verified", "instant_bookable", "host_response_time",
    "room_type", "host_verifications", "bedrooms", "accommodates", "bathrooms",
    "calculated_host_listings_count_entire_homes", "calculated_host_listings_count_private_rooms",
    "price_numeric", "availability_365", "number_of_reviews", "review_scores_value"
]

st.session_state.categorical_vars = [
    v for v in CATEGORICAL_VARS if any(v in df.columns for df in DATA.values())
]
st.session_state.numeric_vars = NUMERIC_VARS


# NAVEGACIÓN

home = st.Page("Paginas/1_Home.py", title="Inicio")
visual = st.Page("Paginas/2_Visualizaciones.py", title="Visualizaciones")
tests = st.Page("Paginas/3_Pruebas_Estadísticas.py", title="Pruebas Estadísticas")
models = st.Page("Paginas/4_Modelos_Predictivos.py", title="Modelos Predictivos")
corr = st.Page("Paginas/5_Correlaciones.py", title="Correlaciones")
export = st.Page("Paginas/6_Exportar.py", title="Exportar")

pg = st.navigation(
    {
        "Principal": [home],
        "Análisis": [visual, tests, models, corr, export]
    }
)

pg.run()